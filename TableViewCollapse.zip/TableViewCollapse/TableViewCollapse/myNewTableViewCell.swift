//
//  myNewTableViewCell.swift
//  TableViewCollapse
//
//  Created by Mani on 29/05/18.
//  Copyright © 2018 mani. All rights reserved.
//

import UIKit

protocol sendIndexPathTableView {
    func indexPathSelected(for cell: Int, isExpanded: Bool)
}

class myNewTableViewCell: UITableViewCell {

    @IBOutlet weak var expandButton: UIButton!
    var index: Int = 0
    var isExpanded = false
    
    var delegate: sendIndexPathTableView?
    
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configureCell()
    }
    
    func configureCell() {
        let title = isExpanded ? "Less Info" : "More Info"
        expandButton.setTitle(title, for: .normal)
    }

    @IBAction func expandClicked(_ sender: Any) {
        isExpanded = !isExpanded
        configureCell()
        delegate?.indexPathSelected(for: index, isExpanded: isExpanded)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        expandButton.setTitle("", for: .normal)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
