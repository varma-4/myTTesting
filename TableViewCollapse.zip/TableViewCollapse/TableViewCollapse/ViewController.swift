//
//  ViewController.swift
//  TableViewCollapse
//
//  Created by Mani on 29/05/18.
//  Copyright © 2018 mani. All rights reserved.
//

import UIKit

class ViewController: UIViewController, sendIndexPathTableView {
    
    var indexPathPrev = Dictionary<String, (index: IndexPath, isExpanded:  Bool)>()
    
    func indexPathSelected(for cellIndex: Int, isExpanded: Bool) {
        let indepath = IndexPath(row: cellIndex, section: 0)
        indexPathPrev["\(cellIndex)"] = (index: indepath, isExpanded: isExpanded)
//        self.myTableView.beginUpdates()
//        self.myTableView.endUpdates()
        self.myTableView.reloadData()
//        let indepaths = indexPathPrev.map({
//            return $0.value.index
//        })
//        self.myTableView.reloadRows(at: indepaths, with: .automatic)
    }
    
    
    
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.myTableView.estimatedRowHeight = 50
//        self.myTableView.rowHeight = UITableViewAutomaticDimension
        self.myTableView.tableFooterView = UIView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        self.myTableView.isEditing = true
        self.myTableView.setEditing(true, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! myNewTableViewCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "myNewCell2", for: indexPath) as! myNewTableViewCell
        cell.delegate = self
        cell.index = indexPath.row
        DispatchQueue.main.async {
            cell.configureCell()
        }
//        cell.configureCell()
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPathPrev.count == 0 { return 125 }
        for indexPathDict in indexPathPrev {
            if indexPath.row != indexPathDict.value.index.row || indexPathDict.value.isExpanded == false {
                continue
            }
            return 256
        }
        return 125
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .none
    }
    
    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    
}

