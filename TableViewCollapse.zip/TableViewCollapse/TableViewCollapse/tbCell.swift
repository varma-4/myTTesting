//
//  tbCell.swift
//  TableViewCollapse
//
//  Created by Mani on 29/05/18.
//  Copyright © 2018 mani. All rights reserved.
//

import UIKit


class TblCell: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    
    @IBAction func onExpandCollepse(_ sender: UIButton) {
        
        sender.isSelected = !sender.isSelected

        if !sender.isSelected{
//            self.lblDetail.numberOfLines = 2
            //            self.constraintBtnHeight.constant = 50
        }else{
            //            self.constraintBtnHeight.constant = 500
//            self.lblDetail.numberOfLines = 0
        }
    }
}
